var app = angular.module("jetbrains", []);
app.controller("appCtrl", function($http){
    var app = this;
    var url = "http://localhost:3000";
    fetchProducts();
    app.save = function(newProduct){
        $http.post(url+'/add', {name:newProduct}).success(function(response){
            fetchProducts();
        });
    };

    function fetchProducts(){
        $http.get(url).success(
            function(response){
                app.products = response;
            }
        );
    }

});

//app.service('fetchProducts', function($http){
//    $http.get(url).success(
//        function(response){
//            app.products = response;
//        }
//    );
//});